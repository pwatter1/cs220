/* shared.h */
#ifndef _SHARED_H
#define _SHARED_H

extern void * logger_malloc (unsigned int size);
extern void logger_free (void *p);

#endif

